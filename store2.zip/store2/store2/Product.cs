﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace store2
{
    public class Product
    {
        public int item_num{get;set;}
        public String description { get; set; }
        public double price { get; set; }
    }
}
