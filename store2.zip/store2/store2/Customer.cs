﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace store2
{
    class Customer
    {
        public int cust_num { get; set; }
        
    }
}
